# RepairAI

نسخه 3.0 اولیه دستیار تعمیرات الکترونیک.

پس از آپلود در GitHub، Workflow با نام **Build RepairAI APK** به‌صورت خودکار APK دیباگ را می‌سازد.
